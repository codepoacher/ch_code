/**
 *  DATE         AUTHOR            INSTRUCTION
 *  2020-08-03   liangsheng.jiang  The first version
 *
 */
#include <stdio.h>
#include "usart.h"

#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#define GETCHAR_PROTOTYPE int __io_getchar(FILE *f)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#define GETCHAR_PROTOTYPE int fgetc(FILE *f)
#endif

PUTCHAR_PROTOTYPE
{
    HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
    return ch;
}

int _write(int file, char *ptr, int len)
{
    int DataIdx;

    for (DataIdx = 0; DataIdx < len; DataIdx++)
    {
        __io_putchar(*ptr++);
    }
    return len;
}

GETCHAR_PROTOTYPE
{
    uint8_t ch = 0;
    HAL_UART_Receive(&huart1, (uint8_t *)&ch, 1, HAL_MAX_DELAY);

    if (ch == '\r')
    {
        __io_putchar('\r');
        ch = '\n';
    }

    return __io_putchar(ch);
    //return ch;
}

int _read (int file, char *ptr, int len)
{
    int DataIdx;

    for (DataIdx = 0; DataIdx < len; DataIdx++)
    {
        //*ptr++ = __io_getchar();
        *ptr = __io_getchar(NULL);
        if (*ptr++ == '\n') break;
    }

    //return len;
    return ++DataIdx;
}