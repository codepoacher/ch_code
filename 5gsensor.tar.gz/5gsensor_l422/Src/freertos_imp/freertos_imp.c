#include  <osal_imp.h>
#include <stdio.h>

#include <FreeRTOS.h>
#include <task.h>
#include <semphr.h>
#include <queue.h>

static void __TaskSleep(int ms)
{
    const TickType_t xDelay = (TickType_t)ms / portTICK_RATE_MS;
    vTaskDelay(xDelay);
}

static void *__TaskCreate(const char *name, int (*taskEntry)(void *args),\
        void *args, int stackSize, void *stack, int prior)
{
    TaskHandle_t xHandle = NULL;
    /* Create the task, storing the handle. */
    xTaskCreate(
                (TaskFunction_t)taskEntry,       /* Function that implements the task. */
                name,          /* Text name for the task. */
                stackSize,      /* Stack size in words, not bytes. */
                (void *)args,    /* Parameter passed into the task. */
                (UBaseType_t)prior,/* Priority at which the task is created. */
                &xHandle );      /* Used to pass out the created task's handle. */

    return (void *)xHandle;
}

static int __TaskKill(void *task)
{
    TaskHandle_t xTask = (TaskHandle_t)task;
    vTaskDelete(xTask);
    return TRUE;
}

static void __TaskExit()
{
    vTaskDelete(NULL);
}

///< this is implement for the mutex
//creat a mutex for the os
static BOOL_T  __MutexCreate(OsalMutexT *mutex)
{
    SemaphoreHandle_t xSemaphore;

    /* Create a mutex type semaphore. */
    xSemaphore = xSemaphoreCreateMutex();

    if( xSemaphore != NULL ) {
        *mutex = (OsalMutexT)xSemaphore;
        return TRUE;
    }
    return FALSE;
}

//lock the mutex
static BOOL_T  __MutexLock(OsalMutexT mutex)
{
    SemaphoreHandle_t xSemaphore;
    xSemaphore = (SemaphoreHandle_t) mutex;

    if(xSemaphoreTake(xSemaphore, portMAX_DELAY) == pdTRUE) {
        return TRUE;
    }
    return FALSE;  
}

//unlock the mutex
static BOOL_T  __MutexUnlock(OsalMutexT mutex)
{
    SemaphoreHandle_t xSemaphore = (SemaphoreHandle_t) mutex;
    if( xSemaphoreGive(xSemaphore) == pdTRUE ) {
        return TRUE;
    }
    return FALSE;
}

//delete the mutex
static BOOL_T  __MutexDel(OsalMutexT mutex)
{
    vSemaphoreDelete((SemaphoreHandle_t) mutex);
    return TRUE;
}


///< this is implement for the semp
//semp of the os
static BOOL_T  __SempCreate(OsalSempT *semp, int limit, int initvalue)
{
    SemaphoreHandle_t xSemaphore;

    /* Attempt to create a semaphore. */
    xSemaphore = xSemaphoreCreateCounting((UBaseType_t) limit, (UBaseType_t) initvalue);
    //xSemaphore = xSemaphoreCreateBinary();

    if( xSemaphore != NULL )
    {
        *semp = (void *) xSemaphore;
        return TRUE;
    }
    return FALSE;
}

static BOOL_T  __SempPend(OsalSempT semp, int timeout)
{
    signed portBASE_TYPE ret;

    if (timeout == 0xffffffff) {
        ret = xSemaphoreTake(semp, portMAX_DELAY);
    } else {
        ret = xSemaphoreTake(semp, timeout);
    }

    return ret == pdPASS ? TRUE : FALSE;
}

static BOOL_T  __SempPost(OsalSempT semp)
{
    signed portBASE_TYPE ret;

    ret = xSemaphoreGive(semp);

    return ret == pdPASS ? TRUE : FALSE;
}

static BOOL_T  __SempDel(OsalSempT semp)
{
    vSemaphoreDelete((SemaphoreHandle_t)semp);
    return TRUE;
}

static BOOL_T __QueueCreate(OsalQueueT *queue, int len, int msgsize)
{
    QueueHandle_t xQueue;
    xQueue = xQueueCreate(len, msgsize);
    if(xQueue != NULL) {
        *queue = (OsalQueueT) xQueue;
        return TRUE;
    }
    return FALSE;
}

static BOOL_T __QueueSend(OsalQueueT queue, void *pbuf, unsigned int bufsize, unsigned int timeout)
{
    if(xQueueSend(queue, pbuf, (TickType_t)timeout) == pdPASS) {
        return TRUE;
    }
    return FALSE;
}

static BOOL_T __QueueRecv(OsalQueueT queue, void *pbuf, unsigned int bufsize, unsigned int timeout)
{
    if(xQueueReceive(queue, pbuf, (TickType_t)timeout) == pdPASS) {
        return TRUE;
    }
    return FALSE;

}

static BOOL_T __QueueDel(OsalQueueT queue)
{
    vQueueDelete((QueueHandle_t)queue);
    return TRUE;
}


static void *__Mem_Malloc(int size)
{
    void *ret = NULL;
    if(size > 0) {
        ret = pvPortMalloc(size);
    }
    return ret;
}

static void __Mem_Free(void *addr)
{
    vPortFree(addr);
}

///< sys time
static unsigned long long __GetSysTime()
{
    return (unsigned long long)xTaskGetTickCount();
}


static const tagOsOps sFreertosOps =
{
    .TaskSleep = __TaskSleep,
    .TaskCreate = __TaskCreate,
    .TaskKill = __TaskKill,
    .TaskExit = __TaskExit,

    .MutexCreate = __MutexCreate,
    .MutexLock = __MutexLock,
    .MutexUnlock = __MutexUnlock,
    .MutexDel = __MutexDel,

    .SempCreate = __SempCreate,
    .SempPend = __SempPend,
    .SempPost = __SempPost,
    .SempDel = __SempDel,

    .QueueCreate = __QueueCreate,
    .QueueSend = __QueueSend,
    .QueueRecv = __QueueRecv,
    .QueueDel = __QueueDel,

    .Malloc = __Mem_Malloc,
    .Free = __Mem_Free,

    .GetSysTime = __GetSysTime,
};

static const tagOs sLinkFreertos =
{
    .name = "FreeRTOS",
    .ops = &sFreertosOps,
};

int ChOsImpInit(void)
{
    int ret = -1;

    ret = ChOsalInstall(&sLinkFreertos);

    return ret;
}
