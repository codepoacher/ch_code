//
// Created by zero on 20/8/6.
//
#include <stdio.h>
#include "FreeRTOS.h"
#include "cmsis_os.h"
#include "task.h"
#include "sensor_manager.h"
#include "communicate_manager.h"
#include "th02.h"
#include "zp07.h"
#include "re46c191.h"

#define OPERATION_SENSOR_HUMIDITY         1
#define OPERATION_SENSOR_AIR_QUALITY    1
#define OPERATION_SENSOR_SMOKE              1

#define HUMIDITY_COLLECT_INTERVAL           50
#define AIR_QUALITY_COLLECT_INTERVAL      50
#define SMOKE_COLLECT_INTERVAL                3000

#ifdef OPERATION_SENSOR_HUMIDITY

static int32_t humiCollectCount = 0;

static int32_t Th02ReadData()
{
    SensorMail sensorMail;
    uint32_t tIVal = 0;
    uint32_t hIVal = 0;

    tIVal = Th02Measure(TH02_TEMP);
    hIVal = Th02Measure(TH02_HUMI);

    if ((tIVal==0) || (hIVal==0)){
        printf("th02  data collection file!\r\n");
        return -1;
    }

    sensorMail.type = SENSOR_TYPE_HUMIDITY;
    sensorMail.humidityData.temp = tIVal;
    sensorMail.humidityData.humi = hIVal;

    TransmitSensorData(&sensorMail);

    return 0;
}
#endif

#ifdef OPERATION_SENSOR_AIR_QUALITY
static int32_t airCollectCount = 0;

static int32_t Zp07ReadData()
{
    SensorMail sensorMail;
    uint32_t airVal = 0;

    airVal = Zp07DataCollection();

    sensorMail.type = SENSOR_TYPE_AIR;
    sensorMail.airData.qualityLevel = airVal;

    TransmitSensorData(&sensorMail);
    return 0;
}
#endif

#ifdef OPERATION_SENSOR_SMOKE
static int32_t somkeCollectCount = 0;

static int32_t Re46c191ReadData()
{
    SensorMail sensorMail;
    uint8_t smokeVal = 0;
    uint8_t smokeStatus = 0;

    smokeStatus = Re46c191DataCollection(&smokeVal);

    if ((smokeStatus == SMOKE_NO_ALARM) && (somkeCollectCount<SMOKE_COLLECT_INTERVAL)) {
        return 0;
    } else {
        somkeCollectCount = 0;
        sensorMail.type = SENSOR_TYPE_SMOKE;
        sensorMail.smokeData.status = smokeVal;
        TransmitSensorData(&sensorMail);
    }

    return 0;
}
#endif

static void SensorTask(void const *arg)
{
#ifdef OPERATION_SENSOR_HUMIDITY
    Th02Init();
#endif

#ifdef OPERATION_SENSOR_AIR_QUALITY
    Zp07Init();
#endif

#ifdef OPERATION_SENSOR_SMOKE
    Re46c191Init();
#endif

    while(1){
#ifdef OPERATION_SENSOR_HUMIDITY
        humiCollectCount++;
        if (humiCollectCount >= HUMIDITY_COLLECT_INTERVAL){
            humiCollectCount = 0;
            Th02ReadData();
        }
#endif
#ifdef OPERATION_SENSOR_AIR_QUALITY
        airCollectCount++;
        if (airCollectCount >= AIR_QUALITY_COLLECT_INTERVAL){
            airCollectCount = 0;
            Zp07ReadData();
        }
#endif
#ifdef OPERATION_SENSOR_SMOKE
        somkeCollectCount++;
        Re46c191ReadData();
#endif
        osDelay(100);
    }
}

int32_t SensorManagerInit()
{
    if (xTaskCreate((TaskFunction_t)SensorTask, "sensorManagerTask", 0x200,
                    NULL, 1, NULL) != pdPASS) {
        printf("Sensor Manager Task create fail !!\r\n");
        return -1;
    }

    return 0;
}