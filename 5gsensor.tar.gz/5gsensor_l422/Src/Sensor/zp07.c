#include "FreeRTOS.h"
#include "task.h"
#include "gpio.h"
#include "zp07.h"
#include "stdio.h"

uint8_t Zp07Init()
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    GPIO_InitStruct.Pin = ZP07_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLDOWN;
    HAL_GPIO_Init(ZP07_GPIOx , &GPIO_InitStruct);

    GPIO_InitStruct.Pin = ZP07_CTRL_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(ZP07_GPIOx, &GPIO_InitStruct);

    ZP07_CTRL_ENABLE;

    return 0;
}

int32_t Zp07DataCollection(void)
{
    TickType_t millisTimes = xTaskGetTickCount();
    TickType_t startMillisTimes = millisTimes;
    TickType_t stopMillisTimes;
    int deltaMillisTimes =  millisTimes - startMillisTimes;
    GPIO_PinState turnState = GPIO_PIN_RESET;
    GPIO_PinState pinState = ZP07_READ_IO;
    GPIO_PinState pinStateLast = pinState;
    int result;

    /* 测试读取状态 */
    while (1) {
        pinState = ZP07_READ_IO;    //读取管脚状态

        if (pinState != pinStateLast) {
            if (turnState == GPIO_PIN_SET) {
                stopMillisTimes = xTaskGetTickCount();
                if (pinState == GPIO_PIN_RESET) {
                    deltaMillisTimes = stopMillisTimes - startMillisTimes;
                } else {
                    deltaMillisTimes = 98 - stopMillisTimes + startMillisTimes;
                }
                result = (deltaMillisTimes + 5) / 10;    //运算结果四舍五入
                break;                    //跳出循环
            }
            if (turnState == GPIO_PIN_RESET) {
                startMillisTimes = xTaskGetTickCount();    //刷新当前时间
                turnState = GPIO_PIN_SET;               //更新标记
            }
            pinStateLast = pinState;
        }

        millisTimes = xTaskGetTickCount();
        deltaMillisTimes = millisTimes - startMillisTimes;
        if ( deltaMillisTimes > 100 ) { //结果判定，超时跳出循环
            if (pinState == GPIO_PIN_SET) {      //空气质量等级10
                result = 10;
            }
            if (pinState == GPIO_PIN_RESET) {     //空气质量等级0
                result = 0;
            }
            break;
        }
    }

    return 10 - result;        //返回空气质量等级结果
}