//
// Created by zero on 20/6/15.
//
#include <stdio.h>
#include <stdbool.h>
#include "cmsis_os.h"
#include "th02.h"
#include "i2c.h"

char Th02Init(void)
{
    char th02DevId = 0;

    HAL_I2C_Mem_Read(&hi2c1, TH02_ADDR_RD,
                    TH02_ID_READ, I2C_MEMADD_SIZE_8BIT,
                    &th02DevId,1, 0x10);

    return th02DevId;
}

uint32_t Th02Measure(uint8_t ucOrder)
{
    uint8_t ucMsb = 0;
    uint8_t ucLsb = 0;
    uint8_t rdy = 0;
    uint8_t flag = 1;
    volatile uint32_t fRetVal = 0;
    uint32_t cov_count = 0;

    uint8_t  readBuffer[2] = {0};

    flag = HAL_I2C_Mem_Write(&hi2c1, TH02_ADDR_WR, 
                            TH02_CONVERSION, I2C_MEMADD_SIZE_8BIT,
                            &ucOrder, 1, 100);
    if(flag != HAL_OK) {
        printf("[err:] i2c_wait_flag=%d, func=%s, line=%d \r\n",
            flag, __FUNCTION__, __LINE__);
        return false;
    }
    osDelay(40);

    cov_count = 0;
    do{
        cov_count++;
        flag = HAL_I2C_Mem_Read(&hi2c1, TH02_ADDR_RD, 
                                TH02_RDY_READ, I2C_MEMADD_SIZE_8BIT,
                                &rdy, 1, 100);
        
    } while (((rdy & 0x01)==1) && (cov_count<1000));
    
    if((rdy & 0x01)==0){
        HAL_I2C_Mem_Read(&hi2c1, TH02_ADDR_RD,
                        TH02_CONVERSION_READ, I2C_MEMADD_SIZE_8BIT,
                        readBuffer,sizeof(readBuffer), 100);
    }else {
        printf("[err:] rdy_flag=%d, func=%s, line=%d \r\n",
            rdy, __FUNCTION__, __LINE__);
        return false;
    }

    ucMsb = readBuffer[0];
    ucLsb = readBuffer[1];
    fRetVal = ucMsb;
    fRetVal = (fRetVal<<8);
    fRetVal += (ucLsb & 0xFC);
    
    if(ucOrder == TH02_TEMP) {
        fRetVal = fRetVal>>2;
        return fRetVal;
    }else if(ucOrder == TH02_HUMI) {
        fRetVal = fRetVal>>4;
        return fRetVal;
    }
    else {
        return false;
    }
}

float Th02HumiOrrection(float hData, float tData)
{
    float rhLinear,rhTempComp;

    rhLinear = hData - (hData * TH02_LINEAR_A1 \
                - (hData * hData) * TH02_LINEAR_A2 - TH02_LINEAR_A0);
    rhTempComp = rhLinear + (tData - 30)  \
                * (rhLinear * TH02_TEMPCOMP_Q1 + TH02_TEMPCOMP_Q0);
    return rhTempComp;
}

float Th02MeasureCalculate(uint8_t ucOrder,uint16_t data)
{
    volatile float fTemp = 0.0;
    volatile float fHumi = 0.0;

    if (data == 0) {
        return 0.0;
    }

    if (ucOrder == TH02_TEMP) {
        fTemp = (float)data / 32.0 - 50.0;
        return fTemp;
    } else if (ucOrder == TH02_HUMI) {
        fHumi = (float)data  / 16.0 - 24.0;
        return fHumi;
    } else {
        return false;
    }
}





