#include <stdio.h>
#include "re46c191.h"
#include "gpio.h"

static uint8_t smokeLastStatus = 0;
static uint8_t smokeStatus = 0;

uint8_t Re46c191Init()
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    GPIO_InitStruct.Pin = RE46C191_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(RE46C191_GPIOx, &GPIO_InitStruct);
    /*
    GPIO_InitStruct.Pin = RE46C191_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(RE46C191_GPIOx, &GPIO_InitStruct);

    HAL_NVIC_SetPriority(EXTI15_10_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
    */
    return 0;
}

int8_t Re46c191DataCollection(uint8_t *data)
{
    smokeStatus = RE46C191_READ_IO;
    if (smokeStatus != smokeLastStatus){
        if ((smokeLastStatus == GPIO_PIN_RESET) && (smokeStatus == GPIO_PIN_SET)) {
            *data = SMOKE_ALARM_SET;
        } else {
            *data = SMOKE_ALARM_RESET;
        }
        smokeLastStatus = smokeStatus;
        return SMOKE_ALARM;
    }

    return SMOKE_NO_ALARM;
}