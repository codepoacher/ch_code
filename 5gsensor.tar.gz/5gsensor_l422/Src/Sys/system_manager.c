//
// Created by zero on 20/9/9.
//
#include <stdio.h>
#include "FreeRTOS.h"
#include "cmsis_os.h"
#include "task.h"
#include "gpio.h"
#include "key.h"
#include "led.h"
#include "module_config.h"

uint32_t heapPrintfCount = 0;

void MemoryHeapState(void)
{
    char pWriteBuffer[128];

    printf("Heap print ----------------------------------------------------- :\n\r");
    printf("current heap4:%d\r\n", (int32_t)xPortGetFreeHeapSize());
    vTaskList((char *)&pWriteBuffer);
    printf("task_name   task_state  priority   stack  tasK_num\n");
    printf("%s\n", pWriteBuffer);
}

static void SystemTestTask(void const *arg)
{
    char pWriteBuffer[128];

    while(1){
        LED1_TOG;
        if (check_click_listener() == KEY_OPT_SHORT){
            BatteryAdcGet();
            LED2_TOG;
        }
        osDelay(200);
    }

}

int32_t SystemTestManagerInit()
{
    if (xTaskCreate((TaskFunction_t)SystemTestTask, "systemManagerTask", 512,
                    NULL, 1, NULL) != pdPASS) {
        printf("sysTest Manager Task create fail !!\r\n");
        return -1;
    }

    return 0;
}