//
// Created by zero on 20/8/31.
//
#include "stdio.h"
#include "gpio.h"
#include "key.h"
#include "log.h"

static uint32_t button_press_count = 0;
static uint8_t button_press_flag= 0;

int8_t KeyGpioInit(void) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    GPIO_InitStruct.Pin = GPIO_PIN_12;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(KEY_GPIOx, &GPIO_InitStruct);

    return 0;
}

uint8_t check_click_listener()
{
    uint8_t ret = 0;
    if (button_press_flag == 0) {
        if ( KEY_READ_IO == GPIO_PIN_RESET) {
            button_press_count++;
            button_press_flag = 1;
        }
    } else {
        if ( KEY_READ_IO == GPIO_PIN_RESET) {
            button_press_count++;
        } else {
            if((button_press_count > 0) && (button_press_count <= 5)){
                //st_printf("key short , buttonPressCount is:%ld\r\n",button_press_count);
                printf("key short , buttonPressCount is:%ld\r\n",button_press_count);
                ret = KEY_OPT_SHORT;
            } else if (button_press_count > 5) {
                //st_printf("key long, buttonPressCount is:%ld\r\n",button_press_count);
                printf("key long, buttonPressCount is:%ld\r\n",button_press_count);
                ret = KEY_OPT_LONG;
            } else {
                //st_printf("key invalid , buttonPressCount is:%ld\r\n",button_press_count);
                printf("key invalid , buttonPressCount is:%ld\r\n",button_press_count);
                ret = KEY_OPT_NONE;
            }
            button_press_count = 0;
            button_press_flag = 0;
        }
    }
    return ret;
}