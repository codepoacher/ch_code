//
// Created by zero on 20/8/24.
//
#include "gpio.h"
#include "led.h"

int8_t LedGpioInit(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(LED_GPIOx, &GPIO_InitStruct);

    LED1_OFF;
    //LED2_OFF	;

    return 0;
}