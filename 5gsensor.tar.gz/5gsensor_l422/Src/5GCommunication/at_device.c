//
// Created by zero on 20/8/6.
//
#include <string.h>
#include "at_device.h"

#include <FreeRTOS.h>
#include <semphr.h>
#include "queue.h"
#include <osal.h>

#define CONFIG_UARTAT_RCVMAX     1024  //cache a frame
#define CONFIG_UARTAT_BAUDRATE    115200
#define CN_RCVMEM_LEN  CONFIG_UARTAT_RCVMAX

#define COMM_5G_UART_PORT USART2

UART_HandleTypeDef uart_at;
static USART_TypeDef*     s_pUSART = COMM_5G_UART_PORT;

struct AtioCb
{
    unsigned short        w_next;    //the next position to be write
    OsalSempT           rcvsync;   //if a frame has been written to the ring, then active it
    TagRingBufferT     rcvring;
    unsigned char         rcvbuf[CONFIG_UARTAT_RCVMAX];
    unsigned char         rcvringmem[CN_RCVMEM_LEN];
    //for the debug here
    unsigned int          rframeover; //how many times the frame has been over the max length
    unsigned int          rframedrop; //how many frame has been droped for memmory
    unsigned int          sndlen;     //how many bytes has been sent
    unsigned int          rcvlen;     //how many bytes has been received
    unsigned int          sndframe;   //how many frame has been sent
    unsigned int          rcvframe;   //how many frame has been received
    unsigned int          rcvringrst; //how many times the receive ring has been reset
};

static struct AtioCb   g_AtioCb;

/*******************************************************************************
function     :use this function to initialize the uart
parameters   :
instruction  :
*******************************************************************************/
BOOL_T UartAtInit(void)
{
    //initialize the at controller
    (void) memset(&g_AtioCb, 0, sizeof(g_AtioCb));

    if (FALSE == ChOsalSempCreate(&g_AtioCb.rcvsync, CN_RCVMEM_LEN, 0)) {
        printf("%s:semp create error\n\r",__FUNCTION__);
        return FALSE;
    }

    RingBufferInit(&g_AtioCb.rcvring, g_AtioCb.rcvringmem, CN_RCVMEM_LEN, 0, 0);

    uart_at.Instance = s_pUSART;
    uart_at.Init.BaudRate = CONFIG_UARTAT_BAUDRATE;
    uart_at.Init.WordLength = UART_WORDLENGTH_8B;
    uart_at.Init.StopBits = UART_STOPBITS_1;
    uart_at.Init.Parity = UART_PARITY_NONE;
    uart_at.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    uart_at.Init.Mode = UART_MODE_TX_RX;
    uart_at.Init.OverSampling = UART_OVERSAMPLING_16;
    if(HAL_UART_Init(&uart_at) != HAL_OK)
    {
        Error_Handler();
    }
    __HAL_UART_CLEAR_FLAG(&uart_at, UART_FLAG_TC);
    __HAL_UART_ENABLE_IT(&uart_at, UART_IT_IDLE);
    __HAL_UART_ENABLE_IT(&uart_at, UART_IT_RXNE);
    return TRUE;
}

void UartAtDeinit(void)
{
    __HAL_UART_DISABLE(&uart_at);
    __HAL_UART_DISABLE_IT(&uart_at, UART_IT_IDLE);
    __HAL_UART_DISABLE_IT(&uart_at, UART_IT_RXNE);
}

int UartAtSend(const char *buf, size_t len, uint32_t timeout)
{
    HAL_UART_Transmit(&uart_at, (unsigned char *)buf, len, timeout);
    g_AtioCb.sndlen += len;
    g_AtioCb.sndframe ++;
    return len;
}

int UartAtReceive(void *buf, size_t len, uint32_t timeout)
{
    unsigned short cpylen;
    unsigned short framelen;
    unsigned short readlen;
    int32_t ret = 0;
    if (ChOsalSempPend(g_AtioCb.rcvsync, timeout)) {
        __HAL_UART_DISABLE_IT(&uart_at, UART_IT_IDLE);
        __HAL_UART_DISABLE_IT(&uart_at, UART_IT_RXNE);
        readlen = sizeof(framelen);
        cpylen = RingBufferRead(&g_AtioCb.rcvring, (unsigned char *)&framelen, readlen);
        if (cpylen != readlen) {
            RingBufferReset(&g_AtioCb.rcvring);  //bad ring format here
            g_AtioCb.rcvringrst++;
        } else {
            if (framelen > len) {
                RingBufferReset(&g_AtioCb.rcvring);  //bad ring format here
                g_AtioCb.rcvringrst++;
            } else {
                readlen = framelen;
                cpylen = RingBufferRead(&g_AtioCb.rcvring, (unsigned char *)buf, readlen);
                if (cpylen != framelen) {
                    RingBufferReset(&g_AtioCb.rcvring);  //bad ring format here
                    g_AtioCb.rcvringrst++;
                } else {
                    ret = cpylen;
                }
            }
        }
        __HAL_UART_CLEAR_FLAG(&uart_at, UART_FLAG_TC);
        __HAL_UART_ENABLE_IT(&uart_at, UART_IT_IDLE);
        __HAL_UART_ENABLE_IT(&uart_at, UART_IT_RXNE);
    }
    return ret;
}

void USER_UART_IRQHandler(UART_HandleTypeDef *huart)
{
    static BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    if (huart->Instance == COMM_5G_UART_PORT) {
        unsigned char  value;
        unsigned short ringspace;
        if (__HAL_UART_GET_FLAG(&uart_at, UART_FLAG_RXNE) != RESET) {
            value = (uint8_t)(uart_at.Instance->RDR & 0x00FF);
            g_AtioCb.rcvlen++;
            if (g_AtioCb.w_next < CONFIG_UARTAT_RCVMAX) {
                g_AtioCb.rcvbuf[g_AtioCb.w_next++] = value;
            } else {
                g_AtioCb.rframeover++;
            }
        } else if (__HAL_UART_GET_FLAG(&uart_at, UART_FLAG_IDLE) != RESET) {
            __HAL_UART_CLEAR_IDLEFLAG(&uart_at);
            ringspace = CN_RCVMEM_LEN - RingBufferDatalen(&g_AtioCb.rcvring);
            if (ringspace < g_AtioCb.w_next) { //not enough mem
                g_AtioCb.rframedrop++;
            } else {
                //write data to the ring buffer:len+data format
                ringspace = g_AtioCb.w_next;
                RingBufferWrite(&g_AtioCb.rcvring, (unsigned char *)&ringspace, sizeof(ringspace));
                RingBufferWrite(&g_AtioCb.rcvring, g_AtioCb.rcvbuf, ringspace);
                xSemaphoreGiveFromISR((SemaphoreHandle_t)g_AtioCb.rcvsync, &xHigherPriorityTaskWoken);
                portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
                g_AtioCb.rcvframe++;
            }
            g_AtioCb.w_next=0; //write from the head
        } else {
            __HAL_UART_CLEAR_PEFLAG(&uart_at);
            __HAL_UART_CLEAR_FEFLAG(&uart_at);
            __HAL_UART_CLEAR_NEFLAG(&uart_at);
            __HAL_UART_CLEAR_OREFLAG(&uart_at);
        }
    }
}

#ifdef PRODUCT_TEST
uint8_t aRx1Buffer;
uint8_t aRx2Buffer;
QueueHandle_t g_uart1Queue;
QueueHandle_t g_uart2Queue;

static int UartTestEntry(void *args)
{
    uint8_t i;
    HAL_UART_Receive_IT(&huart1, (uint8_t *)&aRx1Buffer, 1);
    HAL_UART_Receive_IT(&huart3, (uint8_t *)&aRx2Buffer, 1); 
    while (1) {
        if(xQueueReceive(g_uart2Queue, &i, 0) == pdPASS){
            HAL_UART_Transmit(&huart1, (uint8_t *)&i, 1, 100);
        }

        if(xQueueReceive(g_uart1Queue, &i, 0) == pdPASS){
            HAL_UART_Transmit(&huart3, (uint8_t *)&i, 1, 100);
        }
    }
    return 0;
}

int CommunicateTestInit(void)
{
    ChOsalInit();


    if (NULL == ChOsalTaskCreate("uart_test", UartTestEntry, NULL, 512, NULL, 1)) {
        printf("uart_test task create error\r\n");
        return -1;
    }

    g_uart1Queue = xQueueCreate(5, sizeof(uint8_t));
    g_uart2Queue = xQueueCreate(5, sizeof(uint8_t));

    return 0;
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) 
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE; 
    if (huart->Instance == USART1) {
        xQueueSendToBackFromISR(g_uart1Queue, &aRx1Buffer, &xHigherPriorityTaskWoken);
		HAL_UART_Receive_IT(&huart1, (uint8_t *)&aRx1Buffer, 1);      
    }

    if (huart->Instance == USART3) {
        xQueueSendToBackFromISR(g_uart2Queue, &aRx2Buffer, &xHigherPriorityTaskWoken);
        HAL_UART_Receive_IT(&huart3, (uint8_t *)&aRx2Buffer, 1);
    }
}
#endif

