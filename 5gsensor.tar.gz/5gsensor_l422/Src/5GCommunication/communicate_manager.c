//
// Created by zero on 20/8/6.
//
#include <stdio.h>
#include <string.h>
#include "FreeRTOS.h"
#include "cmsis_os.h"
#include "task.h"
#include "gpio.h"
#include "queue.h"
#include "sensor_manager.h"
#include "at_device.h"
#include "ch_at.h"
#include "th02.h"
#include "re46c191.h"
#include "report.h"
#include "at_http.h"
#include "module_config.h"
#define CONFIG_5G_TASKPRIOR 5
#define SENSOR_MAILS_SIZE 5
#define SENSOR_MAILS_TYPE_SIZE sizeof(SensorMail)

#define TXBUFFERSIZE  2048

QueueHandle_t g_sensorManagerQueue;
SemaphoreHandle_t g_sensorManagerSem;

int32_t TransmitSensorData(SensorMail *sensorMail)
{
    uint32_t ret;
    SensorMail sensorMailRev;

    ret = xQueueSendToBack(g_sensorManagerQueue,(void *)sensorMail,(TickType_t)10);
    if (ret != pdPASS) {//if fail then try again
        ret = xQueueReceive(g_sensorManagerQueue, &sensorMailRev, (TickType_t)10);
        if (ret == pdPASS) {
            ret = xQueueSendToBack(g_sensorManagerQueue,(void *)sensorMail,(TickType_t)10);
            if (ret != pdPASS) {
                printf("trsnsmit_sensor_data write queue agian fail, ret %lu\r\n", ret);
                return -1;
            }
            printf("trsnsmit_sensor_data write queue agian success, ret %lu\r\n", ret);
        } else {
            printf("trsnsmit_sensor_data write queue rev fail, ret %lu\r\n", ret);
            return -1;
        }
    }
    return 0;
}

 void TransmitSensorDatavoidIsr(SensorMail *sensorMail)
{
    portBASE_TYPE pxHigherPriorityTaskWoken = pdTRUE;
    xQueueSendToBackFromISR(g_sensorManagerQueue,(void *)sensorMail,&pxHigherPriorityTaskWoken);
}

static int32_t Th02SensorProcess(const HumidityData *humidityData)
{
    PropertiesReport propertiesReport;
    char tempBuf[20] = {0};
    char humiBuf[20] = {0};
    int16_t tIVal = 0;
    int16_t hIVal = 0;
    float tRetVal = 0.0;
    float hRetVal = 0.0;
    float cHumiRetVal = 0.0;
    int offset = 0;
    char msgbuf[TXBUFFERSIZE + TX_INPUT_END_TAGS_LEN] = {0};

    tIVal = humidityData->temp;
    hIVal = humidityData->humi;
    if (tIVal ==0) {
        return -1;
    }
    tRetVal = Th02MeasureCalculate(TH02_TEMP,tIVal);
    if (hIVal == 0) {
        return -1;
    }
    hRetVal = Th02MeasureCalculate(TH02_HUMI,hIVal);
    cHumiRetVal = Th02HumiOrrection(hRetVal, tRetVal);

    sprintf(tempBuf, "%.2f", tRetVal);
    sprintf(humiBuf, "%.2f", cHumiRetVal);
    propertiesReport.devType = DEV_TYPE_TH02;
    propertiesReport.humidityDataChar.tempChar = tempBuf;
    propertiesReport.humidityDataChar.humiChar = humiBuf;

    offset = SensorsReportEntry(msgbuf, &propertiesReport);
    SendReportByHttp(msgbuf, offset);
    return 0;
}

static int32_t Zp07SensorProcess(const AirData *airData)
{
    PropertiesReport propertiesReport;
    int32_t airVal = 0;
    int offset = 0;
    char msgbuf[TXBUFFERSIZE + TX_INPUT_END_TAGS_LEN] = {0};

    airVal = airData->qualityLevel;

    propertiesReport.devType = DEV_TYPE_ZP07;
    propertiesReport.airData.qualityLevel = airVal;

    offset = SensorsReportEntry(msgbuf, &propertiesReport); 
    SendReportByHttp(msgbuf, offset);
    return 0;
}

static int32_t Re46C191SensorProcess(const SmokeData *smokeData)
{
    PropertiesReport propertiesReport;
    int8_t smokeVal = 0;
    int offset = 0;
    char msgbuf[TXBUFFERSIZE + TX_INPUT_END_TAGS_LEN] = {0};

    smokeVal = smokeData->status;;

    propertiesReport.devType = DEV_TYPE_RE46C191;
    propertiesReport.smokeData.status = smokeVal;

    offset = SensorsReportEntry(msgbuf, &propertiesReport);
    SendReportByHttp(msgbuf, offset);
    return 0;
}


static int Transmit5GTask(void *arg)
{
    int ret = 0;
    SensorMail sensorMail;
    int networkStatusCount = 0;

    ModuleStart();

    while (1) {
        if (pdPASS != xQueueReceive(g_sensorManagerQueue, &sensorMail, (TickType_t)500)) {
            continue;
        }

        /* 检测网络连接状态 */
        networkStatusCount++;
        if (networkStatusCount > 4) {
            ret = AtAIIPCALLQry();
            if (ret < 0) {
                AtAIIPCALLSet();
            }
            networkStatusCount = 0;
        }

        /* 开始上报sensor data */
        if (NETWORK_IS_ON == GetNetworkStatus()) {
            switch (sensorMail.type) {
                case SENSOR_TYPE_HUMIDITY:
                    Th02SensorProcess(&(sensorMail.humidityData));
                    break;
                case SENSOR_TYPE_SMOKE:
                    Re46C191SensorProcess(&(sensorMail.smokeData));
                    break;
                case SENSOR_TYPE_AIR:
                    Zp07SensorProcess(&(sensorMail.airData));
                    break;
                default:
                    break;
            }
        }
        //ChOsalTaskSleep(1000);
    }
    return 0;
}

int32_t CommunicateManagerInit()
{
    ModuleGpioInit();
    ChOsalInit();
    UartAtInit();
    AtInit();

    if (NULL == ChOsalTaskCreate("5GManagerTask", Transmit5GTask, NULL, 2048, NULL, CONFIG_5G_TASKPRIOR)) {
        printf("%s:task create error\r\n", __FUNCTION__);
        return -1;
    }

    g_sensorManagerQueue = xQueueCreate(SENSOR_MAILS_SIZE, SENSOR_MAILS_TYPE_SIZE);

    return 0;
}
