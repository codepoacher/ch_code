/**
 *  DATE         AUTHOR            INSTRUCTION
 *  2020-08-03   liangsheng.jiang  The first version
 *
 */
#include <stdio.h>
#include "FreeRTOS.h"
#include "cJSON.h"
#include "report.h"

int PropertiesReportToJson(char *msgbuf, PropertiesReport *propertiesReport)
{
    int ret = 0;
    char *out = NULL;
    if(NULL == propertiesReport) {
        return -1;
    }

    cJSON *root = NULL;
    cJSON *report = NULL;
    cJSON *properties = NULL;

    root = cJSON_CreateObject();
    report = cJSON_CreateObject();
    properties = cJSON_CreateObject();

    switch (propertiesReport->devType)
    {
        case DEV_TYPE_TH02:
            cJSON_AddItemToObject(properties, "temperature", \
                                  cJSON_CreateString(propertiesReport->humidityDataChar.tempChar));
            cJSON_AddItemToObject(properties, "humidity", \
                                  cJSON_CreateString(propertiesReport->humidityDataChar.humiChar));
            break;
        case DEV_TYPE_RE46C191:
            cJSON_AddItemToObject(properties, "smoke_concentration", \
                                  cJSON_CreateNumber((double)propertiesReport->smokeData.status));
            break;
        case DEV_TYPE_ZP07:
            cJSON_AddItemToObject(properties, "air_quality", \
                                  cJSON_CreateNumber((double)propertiesReport->airData.qualityLevel));
            break;
        default:
            break;
    }
    cJSON_AddItemToObject(report, "devid", cJSON_CreateString(propertiesReport->devId));
    cJSON_AddItemToObject(report, "devtype", cJSON_CreateNumber((double)propertiesReport->devType));
    cJSON_AddItemToObject(report, "properties", properties);

    cJSON_AddItemToObject(root, "msg", cJSON_CreateString(propertiesReport->msg));
    cJSON_AddItemToObject(root, "code", cJSON_CreateNumber((double)propertiesReport->code));
    cJSON_AddItemToObject(root, "report", report);

    out = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    ret = sprintf(msgbuf, "%s", out);
    vPortFree(out);//此处需适配free函数

    return ret;
}

int SensorsReportEntry(char *msgbuf, PropertiesReport *propertiesReport)
{
    int offset = 0;

    propertiesReport->msg = "devicereport";
    propertiesReport->code = 10001;
    propertiesReport->devId = "123456";

    offset = PropertiesReportToJson(msgbuf, propertiesReport);
    printf("current heap4:%d\r\n", (int32_t)xPortGetFreeHeapSize());

    return offset > 0 ? offset : 0;
}