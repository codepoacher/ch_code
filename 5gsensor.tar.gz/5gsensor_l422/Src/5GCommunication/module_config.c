//
// Created by zero on 20/8/12.
//
#include <stdio.h>
#include "FreeRTOS.h"
#include "cmsis_os.h"
#include "gpio.h"
#include "adc.h"
#include "module_config.h"

uint16_t BatteryAdcGet(void)
{
    uint16_t adcValue = 0;
    float refValue = 0.0;
    float batValue = 0.0;

    HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED);
    HAL_ADC_Start(&hadc1);
    HAL_ADC_PollForConversion(&hadc1, 50);

    if (HAL_IS_BIT_SET(HAL_ADC_GetState(&hadc1), HAL_ADC_STATE_REG_EOC)) {
        adcValue = HAL_ADC_GetValue(&hadc1);
        printf("ADC10 reading %d \r\n",adcValue);
        refValue = adcValue*3.347f/4096;
        printf("ADC10 refValue : %.4f \r\n",refValue);
        batValue = refValue * (100 + 249) / 249;
        printf("ADC10 batValue : %.4f \r\n",batValue);
    }
    return adcValue;
}

int8_t ModuleGpioInit(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    GPIO_InitStruct.Pin = MODULE_CHECK_WAKE__PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(MODULE_CHECK_WAKE_GPIOx , &GPIO_InitStruct);

    GPIO_InitStruct.Pin = MODULE_WAKE_CTR__PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(MODULE_WAKE_CTR_GPIOx, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = MODULE_PWR_CTR__PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(MODULE_PWR_CTR_GPIOx, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = MODULE_RESET_CTR__PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(MODULE_RESET_CTR_GPIOx, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = MODULE_RF_CTR__PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(MODULE_RF_CTR_GPIOx, &GPIO_InitStruct);

    return 0;
}

int8_t ModuleStart(void)
{
    MODULE_PWR_CTR_H;
    MODULE_RESET_CTR_H;
    MODULE_WAKE_CTR_H;
    MODULE_RF_CTR_H;

    osDelay(10);

    MODULE_PWR_CTR_L;
    osDelay(600);

    return 0;
}


