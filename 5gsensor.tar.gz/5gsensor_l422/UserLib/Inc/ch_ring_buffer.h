/**
 *  DATE                AUTHOR      INSTRUCTION
 *  2020-08-17          jls         The first version
 */
#ifndef _CH_RING_BUFFER_H_
#define _CH_RING_BUFFER_H_

typedef struct
{
    unsigned char   *buf;      ///< which means the buffer
    int              buflen;   ///< which means the buffer limit
    int              datalen;  ///< which means how many data in the buffer
    int              dataoff;  ///< which means the valid data offset in the buffer
}TagRingBufferT;

typedef TagRingBufferT  RingBufferT;

int RingBufferInit(TagRingBufferT *ring, unsigned char *buf, int buflen, int offset, int datalen);
int RingBufferWrite(TagRingBufferT *ring, unsigned char *buf, int len);
int RingBufferRead(TagRingBufferT *ring, unsigned char *buf, int len);
int RingBufferDatalen(TagRingBufferT *ring);
int RingBufferFreespace(TagRingBufferT *ring);
int RingBufferReset(TagRingBufferT *ring);
int RingBufferDeinit(TagRingBufferT *ring);



#endif /* _CH_RING_BUFFER_H_ */
