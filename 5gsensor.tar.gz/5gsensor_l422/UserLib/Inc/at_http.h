/**
 *  DATE                AUTHOR      INSTRUCTION
 *  2020-08-17          jls         The first version
 */
#ifndef _AT_HTTP_H_
#define _AT_HTTP_H_

typedef enum {
    NETWORK_IS_OFF,
    NETWORK_IS_ON
}NetworkStatus;

#define SEND_CMD_WAIT_TIME 5000
#define TX_INPUT_END_TAGS "+++"
#define TX_INPUT_END_TAGS_LEN 3


//内置协议栈连接 ^AIIPCALL set
#define AT_AIIPCALL_SET_CMD "AT^AIIPCALL=1,1,\"ctnet\",\"\",\"\",2"
#define AT_AIIPCALL_SET_CHECK "^AIIPCALL:1,1"
//内置协议栈连接 ^AIIPCALL qry
#define AT_AIIPCALL_QRY_CMD "AT^AIIPCALL?"
#define AT_AIIPCALL_QRY_CHECK "^AIIPCALL:1,1"
//配置HTTP参数 ^AIHTTPCFG set
#define AT_AIHTTPCFG_SET_URL_CMD "AT^AIHTTPCFG=URL,\"https://www.baidu.com\""
#define AT_AIHTTPCFG_SET_URL_CHECK "\r\nOK\r\n"
#define AT_AIHTTPCFG_SET_USERAGENT_CMD "AT^AIHTTPCFG=USERAGENT,\"Ai Client/1.0\""
#define AT_AIHTTPCFG_SET_USERAGENT_CHECK "\r\nOK\r\n"
#define AT_AIHTTPCFG_SET_HASHEADER_CMD "AT^AIHTTPCFG=HASHEADER,0"
#define AT_AIHTTPCFG_SET_HASHEADER_CHECK "\r\nOK\r\n"
//配置HTTP请求头 ^AIHTTPHEADER set
#define AT_AIHTTPHEADER_SET_ACCEPT_CMD "AT^AIHTTPHEADER=\"Accept\",\"*/*\""
#define AT_AIHTTPHEADER_SET_ACCEPT_CHECK "\r\nOK\r\n"
#define AT_AIHTTPHEADER_SET_ACCEPT_LANGUAGE_CMD "AT^AIHTTPHEADER=\"Accept-Language\",\"zh-cn\""
#define AT_AIHTTPHEADER_SET_ACCEPT_LANGUAGE_CHECK "\r\nOK\r\n"
//设置HTTP请求数据 ^AIHTTPDATA
#define AT_AIHTTPDATA_SET_CMD "AT^AIHTTPDATA=%d"
#define AT_AIHTTPDATA_SET_CHECK "\r\n>"
#define AT_AIHTTPDATA_SET_DATA_END_CHECK "\r\nOK\r\n"
//执行HTTP请求 ^AIHTTPACT
#define AT_AIHTTPACT_SET_CMD "AT^AIHTTPACT=1,1,0,18"
#define AT_AIHTTPACT_SET_CHECK "^AIHTTPRSP:0"
//读取数据 ^AIHTTPREAD
#define AT_AIHTTPREAD_SET_CMD "AT^AIHTTPREAD=0,1000"
#define AT_AIHTTPREAD_SET_CHECK "^AIHTTPREAD:0"    //可改为http响应返回的具体内容，如："report successed."


int GetNetworkStatus(void);
void SetNetworkStatus(int status);

int AtAIIPCALLSet(void);
int AtAIIPCALLQry(void);

int AtAIHTTPCFGSet(void);
int AtAIHTTPHEADERSet(void);
int AtAIHTTPDATASet(char *msgbuf, int dataLen);
int AtAIHTTPACTSet(void);
int AtAIHTTPREADSet(void);

int SendReportByHttp(char *msgbuf, int dataLen);

#endif /* _AT_HTTP_H_ */

