#ifndef __OS_AL_H
#define __OS_AL_H

#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

//#include <link_misc.h>
#include "osal_types.h"

//we need nothing here except the standard struct here
//kernel port here
//create a task:return the task handle here while -1 means create failed

/**
 * @brief:use this function to create a task here
 *
 * @param[in]:name, task name
 * @param[in]:taskEntry, the task entry function
 * @param[in]:stackSize,the task stack size
 * @param[in]:stack, the stack memory, if NULL, which needed malloc by the system
 * @param[in]:args,the parameter pass to the entry function
 * @param[in]:prior,the prior if supported for the task;the bigger value, the lower prior
 *
 * @return:the task handle, while NULL failed
 *
 * */
void* ChOsalTaskCreate(const char *name, int (*taskEntry)(void *args),\
                      void *args, int stackSize, void *stack, int prior);

/**
 * @brief:use this funciton to kill the task
 *
 * @param[in]:task, the object get from TaskCreate
 *
 * @return:0 success while FALSE failed
 * */
int ChOsalTaskKill(void *task);

/**
 * @brief:use this function  to exit from the current task
 *
 **/
void ChOsalTaskExit();

/**
 * @brief:use this function to make the task to sleep
 *
 * @param[in]:ms, how much time to sleep, unit:ms
 *
 * @return:0 success while -1 failed
 **/
void ChOsalTaskSleep(int ms);

/**
 *@brief: the mutex that the os must supplied for the link
 *
 **/

BOOL_T  ChOsalMutexCreate(OsalMutexT *mutex);
BOOL_T  ChOsalMutexLock(OsalMutexT mutex);
BOOL_T  ChOsalMutexUnlock(OsalMutexT mutex);
BOOL_T  ChOsalMutexDel(OsalMutexT mutex);

/**
 *@brief: the semp method that the os must supplied for the link
 *
 **/
BOOL_T  ChOsalSempCreate(OsalSempT *semp, int limit, int initvalue);
BOOL_T  ChOsalSempPend(OsalSempT semp, int timeout);
BOOL_T  ChOsalSempPost(OsalSempT semp);
BOOL_T  ChOsalSempDel(OsalSempT semp);

/**
 *@brief: the queue method that the os must supplied for the link
 *
 **/
BOOL_T  ChOsalQueueCreate(OsalQueueT *queue, int len, int msgsize);
BOOL_T  ChOsalQueueSend(OsalQueueT queue, void *pbuf, unsigned int bufsize, unsigned int timeout);
BOOL_T  ChOsalQueueRecv(OsalQueueT queue, void *pbuf, unsigned int bufsize, unsigned int timeout);
BOOL_T  ChOsalQueueDel(OsalQueueT queue);


/**
 *@brief: the memory method that the os must supplied for the link
 *
 **/
void *ChOsalMalloc(size_t size);
void  ChOsalFree(void *addr);
void *ChOsalZalloc(size_t size);
void *ChOsalRealloc(void *ptr, size_t newsize);
void *ChOsalCalloc(size_t n, size_t size);


/**
 * @brief: use this function to get the system time
 *
 * @return:system time (unit ms)
 * */
unsigned long long ChOsalSysTime();

/**
 *
 * @brief: the loop soft timer
 * @param[in] : timer, the loop timer to be initialized
 *
 * */
void ChOsalLoopTimerInit(OsalLoopTimerT *timer);

/**
 *
 * @brief: the loop soft timer
 * @param[in] : timer, the loop timer
 *
 * @return: TRUE expired while FALSE not expired
 *
 * */
char ChOsalLoopTimerExpired(OsalLoopTimerT *timer);

/**
 *
 * @brief: the loop soft timer
 * @param[in]: timer, the loop timer
 * @param[in]: timeout, how many time to be expired,unit:second
 *
 * */
void ChOsalLoopTimerCountDown(OsalLoopTimerT *timer, unsigned int timeout);
/**
 *
 * @brief: the loop soft timer
 * @param[in]: timer, the loop timer
 * @param[in]: timeout, how many time to be expired,unit:ms
 *
 * */
void ChOsalLoopTimerCountDownms(OsalLoopTimerT *timer, unsigned int timeout);

/**
 *
 * @brief: the loop soft timer
 * @param[in]: timer, the loop timer
 * @return: how many ms to be expired
 * */
int ChOsalLoopTimerLeft(OsalLoopTimerT *timer);




/**
 * @brief:  you could use this function to do the system reboot
 *
 *
 * */
int ChOsalReboot(void);



int ChOsalIntConnect(int intnum, int prio, int mode, FnInterruptHandle callback, void *arg);

/**
 * @brief:use this function to initialize the os abstract layer
 *
 * @return:0 success while -1 failed
 * */
int ChOsalInit(void);


#endif /* __OS_AL_H */
