/**
 *  DATE                AUTHOR      INSTRUCTION
 *  2020-08-17          jls         The first version
 */
#ifndef _CH_AT_H_
#define _CH_AT_H_

#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <osal.h>

typedef int (*FnAtOob)(void *args, void *data, size_t datalen);

/**
 * @brief: use this function to do the at client framwork initialized
 *
 * @return:0 success while -1 failed
 * */
int AtInit();

/**
 * @brief:use this function to register a function that monitor the URC message
 * @param[in]:name, which used for the at framework debug
 * @param[in]:inxdex, used for match the out of band data
 * @param[in]:length, index length, this is match length
 * @param[in]:func, supply the function that will execute when the index is matched
 * @paarm[in]:args, supply for the registered function
 *
 * @return:0 success while -1 failed
 * */
int AtOobregister(const char *name, const void *index, size_t len, FnAtOob func, void *args);

/**
 * @brief:use this function to register a function that monitor the URC message
 * @param[in]:cmd, the command to send
 * @param[in]:cmdlen, the command length
 * @param[in]:index, the command index, if you don't need the response, set it to NULL; this must be a string
 * @param[in]:respbuf, if you need the response, you should supply the buffer
 * @param[in]:respbuflen,the respbuf length
 * @param[in]:timeout, the time you may wait for the response;and the unit is ms
 *
 * @return:>=0 success (return the received data length) while -1 failed
 * */
int AtCommand(const void *cmd, size_t cmdlen, const char *index, void *respbuf, \
                    size_t respbuflen, uint32_t timeout);
int AtStreammodeSt(int mode);
int AtDebugclose(void);

#endif /* _CH_AT_H_ */

