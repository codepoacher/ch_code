/*
 * osal_types.h
 */

#ifndef __OSAL_TYPES_H
#define __OSAL_TYPES_H

#ifndef BOOL_T
#define BOOL_T int
#endif
#ifndef TRUE
#define TRUE  1
#endif
#ifndef FALSE
#define FALSE 0
#endif
typedef void*  OsalMutexT;
#define CN_MUTEX_INVALID  ((OsalMutexT)0xFFFFFFFF)

typedef void*  OsalSempT;
#define CN_SEMP_INVALID   ((OsalSempT)0xFFFFFFFF)

typedef void* OsalQueueT;
#define CN_QUEUE_INVALID   ((OsalQueueT)0xFFFFFFFF)


#define CN_OSAL_TIMEOUT_FOREVER  0xFFFFFFFF

typedef struct
{
    unsigned long long deadTime;
}OsalLoopTimerT;

typedef void (*FnInterruptHandle)(void* arg);

enum SwtmrType
{
    SWTMR_MODE_ONCE,                 /**< One-off software timer */
    SWTMR_MODE_PERIOD,               /**< Periodic software timer */
    SWTMR_MODE_NO_SELFDELETE,        /**< One-off software timer, but not self-delete */
};

#endif /* __OSAL_TYPES_H */
