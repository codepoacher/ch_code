/*
 * osal_imp.h
 */

#ifndef __OSAL_IMP_H
#define __OSAL_IMP_H


#include <osal_types.h>

typedef struct
{
    ///< task function needed
    void* (*TaskCreate)(const char *name, int (*taskEntry)(void *args),\
                      void *args, int stackSize, void *stack, int prior);
    int   (*TaskKill)(void *task);
    void  (*TaskExit)();
    void  (*TaskSleep)(int ms);

    ///< mutex function needed
    BOOL_T  (* MutexCreate)(OsalMutexT *mutex);
    BOOL_T  (* MutexLock)(OsalMutexT mutex);
    BOOL_T  (* MutexUnlock)(OsalMutexT mutex);
    BOOL_T  (* MutexDel)(OsalMutexT mutex);

    ///< semp function needed
    BOOL_T (*SempCreate)(OsalSempT *semp, int limit, int initvalue);
    BOOL_T (*SempPend)(OsalSempT semp, int timeout);
    BOOL_T (*SempPost)(OsalSempT semp);
    BOOL_T (*SempDel)(OsalSempT semp);

    ///< queue function needed
    BOOL_T (*QueueCreate)(OsalQueueT *queue, int len, int msgsize);
    BOOL_T (*QueueSend)(OsalQueueT queue, void *pbuf, unsigned int bufsize, unsigned int timeout);
    BOOL_T (*QueueRecv)(OsalQueueT queue, void *pbuf, unsigned int bufsize, unsigned int timeout);
    BOOL_T (*QueueDel)(OsalQueueT queue);

    ///< memory function needed
    void *(*Malloc)(int size);
    void  (*Free)(void *addr);
    void *(*Realloc)(void *ptr, int newsize);


    ///< system time
    unsigned long long (*GetSysTime)(void);

    ///< reboot
    int (*Reboot)(void); ///< never come back only if failed

    int (*IntConnect)(int intnum, int prio, int mode, FnInterruptHandle callback, void *arg);

}tagOsOps;


typedef struct
{
    const char       *name;  ///< operation system name
    const tagOsOps   *ops;   ///< system function interface
}tagOs;

int ChOsalInstall(const tagOs *os); //install the os to the link layer


#endif /* __OSAL_IMP_H */
