#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>


#include <string.h>

#include "osal_imp.h"
#include "osal.h"

static const tagOs *sOsCb = NULL;

int ChOsalInstall(const tagOs *os)
{
    int ret = -1;

    if(NULL == sOsCb)
    {
        sOsCb = os;
        ret = 0;
    }

    return ret;
}


void* ChOsalTaskCreate(const char *name, int (*taskEntry)(void *args),\
                      void *args, int stackSize, void *stack, int prior)
{
    void *ret = NULL;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->TaskCreate))
    {
        ret = sOsCb->ops->TaskCreate(name, taskEntry, args, stackSize, stack, prior);
    }

    return ret;
}


int ChOsalTaskKill(void *task)
{
    int ret = -1;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->TaskKill))
    {
        ret = sOsCb->ops->TaskKill(task);
    }

    return ret;

}


void ChOsalTaskExit()
{

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->TaskExit))
    {
        sOsCb->ops->TaskExit();
    }
    return ;

}


void ChOsalTaskSleep(int ms)
{
    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->TaskSleep))
    {
        sOsCb->ops->TaskSleep(ms);
    }

    return ;

}


BOOL_T  ChOsalMutexCreate(OsalMutexT *mutex)
{
    BOOL_T ret = FALSE;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->MutexCreate))
    {
        ret = sOsCb->ops->MutexCreate(mutex);
    }

    return ret;

}


BOOL_T  ChOsalMutexLock(OsalMutexT mutex)
{
    BOOL_T ret = FALSE;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->MutexLock))
    {
        ret = sOsCb->ops->MutexLock(mutex);
    }

    return ret;

}


BOOL_T  ChOsalMutexUnlock(OsalMutexT mutex)
{
    BOOL_T ret = FALSE;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->MutexUnlock))
    {
        ret = sOsCb->ops->MutexUnlock(mutex);
    }

    return ret;

}

BOOL_T  ChOsalMutexDel(OsalMutexT mutex)
{
    BOOL_T ret = FALSE;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->MutexDel))
    {
        ret = sOsCb->ops->MutexDel(mutex);
    }

    return ret;

}

BOOL_T  ChOsalSempCreate(OsalSempT *semp, int limit, int initvalue)
{
    BOOL_T ret = FALSE;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->SempCreate))
    {
        ret = sOsCb->ops->SempCreate(semp, limit, initvalue);
    }

    return ret;

}

BOOL_T  ChOsalSempPend(OsalSempT semp, int timeout)
{
    BOOL_T ret = FALSE;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->SempPend))
    {
        ret = sOsCb->ops->SempPend(semp, timeout);
    }

    return ret;

}


BOOL_T  ChOsalSempPost(OsalSempT semp)
{
    BOOL_T ret = FALSE;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->SempPost))
    {
        ret = sOsCb->ops->SempPost(semp);
    }

    return ret;

}

BOOL_T  ChOsalSempDel(OsalSempT semp)
{
    BOOL_T ret = FALSE;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->SempDel))
    {
        ret = sOsCb->ops->SempDel(semp);
    }

    return ret;

}

BOOL_T  ChOsalQueueCreate(OsalQueueT *queue, int len, int msgsize)
{
    BOOL_T ret = FALSE;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->QueueCreate))
    {
        ret = sOsCb->ops->QueueCreate( queue, len, msgsize);
    }

    return ret;
}

BOOL_T  ChOsalQueueSend(OsalQueueT queue, void *pbuf, unsigned int bufsize, unsigned int timeout)
{
    BOOL_T ret = FALSE;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->QueueSend))
    {
        ret = sOsCb->ops->QueueSend( queue, pbuf, bufsize, timeout);
    }

    return ret;
}

BOOL_T  ChOsalQueueRecv(OsalQueueT queue, void *pbuf, unsigned int bufsize, unsigned int timeout)
{
    BOOL_T ret = FALSE;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->QueueRecv))
    {
        ret = sOsCb->ops->QueueRecv( queue, pbuf, bufsize, timeout);
    }

    return ret;
}

BOOL_T  ChOsalQueueDel(OsalQueueT queue)
{
    BOOL_T ret = FALSE;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->QueueDel))
    {
        ret = sOsCb->ops->QueueDel( queue);
    }

    return ret;
}


void *ChOsalMalloc(size_t size)
{
    void *ret = NULL;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->Malloc))
    {
        ret = sOsCb->ops->Malloc(size);
    }

    return ret;

}

void  ChOsalFree(void *addr)
{

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->Free))
    {
        sOsCb->ops->Free(addr);
    }

    return;
}

void *ChOsalZalloc(size_t size)
{
    void *ret = NULL;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->Malloc))
    {
        ret = sOsCb->ops->Malloc(size);
        if(NULL != ret)
        {
            memset(ret,0,size);
        }
    }

    return ret;

}

void *ChOsalRealloc(void *ptr,size_t newsize)
{
    void *ret = NULL;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->Realloc))
    {
        ret = sOsCb->ops->Realloc(ptr,newsize);
    }

    return ret;
}

void *ChOsalCalloc(size_t n, size_t size)
{
    void *p = ChOsalMalloc(n * size);
    if(NULL != p)
    {
        memset(p, 0, n * size);
    }

    return p;
}



unsigned long long ChOsalSysTime()
{

    unsigned long long  ret = 0;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->GetSysTime))
    {
        ret = sOsCb->ops->GetSysTime();
    }

    return ret;
}

void ChOsalLoopTimerInit(OsalLoopTimerT *timer)
{
    timer->deadTime = ChOsalSysTime();
}

char ChOsalLoopTimerExpired(OsalLoopTimerT *timer)
{
    unsigned long long now = ChOsalSysTime();
    return now >= timer->deadTime;
}

void ChOsalLoopTimerCountDownms(OsalLoopTimerT *timer, unsigned int timeout)
{
    unsigned long long now = ChOsalSysTime();
    timer->deadTime = now + timeout;
}


void ChOsalLoopTimerCountDown(OsalLoopTimerT *timer, unsigned int timeout)
{
    ChOsalLoopTimerCountDownms(timer, timeout*1000);
}

int ChOsalLoopTimerLeft(OsalLoopTimerT *timer)
{
    unsigned long long now = ChOsalSysTime();
    return timer->deadTime <= now ? 0 : timer->deadTime - now;
}




int ChOsalReboot()  ///< maybe we should never come back
{
    int ret = -1;

    if((NULL != sOsCb) && (NULL != sOsCb->ops) && (NULL != sOsCb->ops->Reboot))
    {
        ret = sOsCb->ops->Reboot();
    }

    return ret;
}



int ChOsalIntConnect(int intnum, int prio, int mode, FnInterruptHandle callback, void *arg)
{
	int ret = -1;
	if((NULL != sOsCb) &&(NULL != sOsCb->ops) &&(NULL != sOsCb->ops->IntConnect))
    {
        ret = sOsCb->ops->IntConnect(intnum, prio, mode, callback, arg);
    }

	return ret;
}

__attribute__((weak))  int ChOsImpInit(void)
{
    printf("%s:###please implement this function by yourself####\n\r",__FUNCTION__);
    return -1;
}

int ChOsalInit(void)
{
    int ret = -1;
    ret = ChOsImpInit();
    return ret;
}

