#include <osal.h>
#include <ch_at.h>
#include <string.h>
#include "at_http.h"

#define RSP_BUFFER_LEN 2048 //等于ch_at.c中CONFIG_AT_RECVMAXLEN

static NetworkStatus isConnectedNetwork = NETWORK_IS_OFF;

static char rspBuffer[RSP_BUFFER_LEN] = {0};

int GetNetworkStatus(void)
{
    return isConnectedNetwork;
}

void SetNetworkStatus(int status)
{
    isConnectedNetwork = status;
}

char* GetRspBuf(void)
{
    return rspBuffer;
}

//内置协议栈连接 ^AIIPCALL set
int AtAIIPCALLSet(void)
{
    int ret = -1;
    memset(rspBuffer, 0x00, RSP_BUFFER_LEN);
    ret = AtCommand(AT_AIIPCALL_SET_CMD, strlen(AT_AIIPCALL_SET_CMD), AT_AIIPCALL_SET_CHECK, \
                    rspBuffer, RSP_BUFFER_LEN, SEND_CMD_WAIT_TIME);
    if (ret < 0) {
        if (NETWORK_IS_ON == GetNetworkStatus()) {
            SetNetworkStatus(NETWORK_IS_OFF);
        }
    } else {
        if (NETWORK_IS_OFF == GetNetworkStatus()) {
            SetNetworkStatus(NETWORK_IS_ON);
        }
    }
    return ret;
}

//内置协议栈连接 ^AIIPCALL qry
int AtAIIPCALLQry(void)
{
    int ret = -1;
    memset(rspBuffer, 0x00, RSP_BUFFER_LEN);
    ret =  AtCommand(AT_AIIPCALL_QRY_CMD, strlen(AT_AIIPCALL_QRY_CMD), AT_AIIPCALL_QRY_CHECK, \
                     rspBuffer, RSP_BUFFER_LEN, SEND_CMD_WAIT_TIME);
    printf("%s,line=%d,ret=%d,networkstate=%d\r\n",__func__,__LINE__,ret,GetNetworkStatus());
    if (ret < 0) {
        if (NETWORK_IS_ON == GetNetworkStatus()) {
            SetNetworkStatus(NETWORK_IS_OFF);
        }
    } else {
        if (NETWORK_IS_OFF == GetNetworkStatus()) {
            SetNetworkStatus(NETWORK_IS_ON);
        }
    }
    return ret;
}

//配置HTTP参数 ^AIHTTPCFG set
int AtAIHTTPCFGSet(void)
{
    int ret = -1;
    memset(rspBuffer, 0x00, RSP_BUFFER_LEN);
    ret =  AtCommand(AT_AIHTTPCFG_SET_URL_CMD, strlen(AT_AIHTTPCFG_SET_URL_CMD), AT_AIHTTPCFG_SET_URL_CHECK, \
                     rspBuffer, RSP_BUFFER_LEN, SEND_CMD_WAIT_TIME);
    if (ret < 0) {
        return ret;
    }
    memset(rspBuffer, 0x00, RSP_BUFFER_LEN);
    ret =  AtCommand(AT_AIHTTPCFG_SET_USERAGENT_CMD, strlen(AT_AIHTTPCFG_SET_USERAGENT_CMD), \
                     AT_AIHTTPCFG_SET_USERAGENT_CHECK, rspBuffer, RSP_BUFFER_LEN, SEND_CMD_WAIT_TIME);
    if (ret < 0) {
        return ret;
    }
    memset(rspBuffer, 0x00, RSP_BUFFER_LEN);
    ret =  AtCommand(AT_AIHTTPCFG_SET_HASHEADER_CMD, strlen(AT_AIHTTPCFG_SET_HASHEADER_CMD), \
                     AT_AIHTTPCFG_SET_HASHEADER_CHECK, rspBuffer, RSP_BUFFER_LEN, SEND_CMD_WAIT_TIME);
    return ret;
}

//配置HTTP请求头 ^AIHTTPHEADER set
int AtAIHTTPHEADERSet(void)
{
    int ret = -1;
    memset(rspBuffer, 0x00, RSP_BUFFER_LEN);
    ret =  AtCommand(AT_AIHTTPHEADER_SET_ACCEPT_CMD, strlen(AT_AIHTTPHEADER_SET_ACCEPT_CMD), \
                     AT_AIHTTPHEADER_SET_ACCEPT_CHECK, rspBuffer, RSP_BUFFER_LEN, SEND_CMD_WAIT_TIME);
    if (ret < 0) {
        return ret;
    }
    memset(rspBuffer, 0x00, RSP_BUFFER_LEN);
    ret =  AtCommand(AT_AIHTTPHEADER_SET_ACCEPT_LANGUAGE_CMD, strlen(AT_AIHTTPHEADER_SET_ACCEPT_LANGUAGE_CMD), \
                     AT_AIHTTPHEADER_SET_ACCEPT_LANGUAGE_CHECK, rspBuffer, RSP_BUFFER_LEN, SEND_CMD_WAIT_TIME);
    return ret;
}

//设置HTTP请求数据 ^AIHTTPDATA
int AtAIHTTPDATASet(char *msgbuf, int dataLen)
{
    int ret = -1;
    char atBuf[30] = {0};
    sprintf(atBuf, AT_AIHTTPDATA_SET_CMD, dataLen);

    memset(rspBuffer, 0x00, RSP_BUFFER_LEN);
    ret =  AtCommand(atBuf, strlen(atBuf), AT_AIHTTPDATA_SET_CHECK, rspBuffer, RSP_BUFFER_LEN, SEND_CMD_WAIT_TIME);
    if (ret < 0) {
        return ret;
    }
    //开始传输数据
    strcat(msgbuf, TX_INPUT_END_TAGS);
    memset(rspBuffer, 0x00, RSP_BUFFER_LEN);
    ret =  AtCommand(msgbuf, strlen(msgbuf), AT_AIHTTPDATA_SET_DATA_END_CHECK, \
                     rspBuffer, RSP_BUFFER_LEN, SEND_CMD_WAIT_TIME);
    return ret;
}

//执行HTTP请求 ^AIHTTPACT
int AtAIHTTPACTSet(void)
{
    int ret = -1;
    memset(rspBuffer, 0x00, RSP_BUFFER_LEN);
    ret =  AtCommand(AT_AIHTTPACT_SET_CMD, strlen(AT_AIHTTPACT_SET_CMD), \
                     AT_AIHTTPACT_SET_CHECK, rspBuffer, RSP_BUFFER_LEN, SEND_CMD_WAIT_TIME);
    return ret;
}

//读取数据 ^AIHTTPREAD
int AtAIHTTPREADSet(void)
{
    int ret = -1;
    memset(rspBuffer, 0x00, RSP_BUFFER_LEN);
    ret =  AtCommand(AT_AIHTTPREAD_SET_CMD, strlen(AT_AIHTTPREAD_SET_CMD), \
                     AT_AIHTTPREAD_SET_CHECK, rspBuffer, RSP_BUFFER_LEN, SEND_CMD_WAIT_TIME);
    return ret;
}

int SendReportByHttp(char *msgbuf, int dataLen)
{
    int ret = -1;
    ret = AtAIHTTPCFGSet();
    if (ret < 0) {
        return ret;
    }
    ret = AtAIHTTPHEADERSet();
    if (ret < 0) {
        return ret;
    }
    ret = AtAIHTTPDATASet(msgbuf, dataLen);
    if (ret < 0) {
        return ret;
    }
    ret = AtAIHTTPACTSet();
    if (ret < 0) {
        return ret;
    }
    ChOsalTaskSleep(500);
    ret = AtAIHTTPREADSet();
    return ret;
}