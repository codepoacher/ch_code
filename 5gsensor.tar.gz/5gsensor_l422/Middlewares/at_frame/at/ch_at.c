#include <ch_at.h>
#include <stdlib.h>
#include <string.h>
#include <sys/fcntl.h>
#include <ctype.h>

#define CONFIG_AT_OOBTABLEN              6 //only allow 6 oob command monitor here
#define CONFIG_AT_RECVMAXLEN             2048
#define CONFIG_AT_TASKPRIOR              5

//at control block here
typedef struct {
    const void *cmd;               //pointed to the at command
    size_t      cmdlen;            //how many bytes of the command for the command may not be string(binary string)
    const char *index;             //used to check if the frame is the response of the command
    const void *respbuf;           //which used to storage the response,supplied by the at command
    size_t      respbuflen;        //index the response buffer length,supplied by the at command
    size_t      respdatalen;       //index how many data in the response buffer, filled by the at engine
    OsalSempT      respsync;     //binary semphore, activated by the at engine,if any response matched
    OsalSempT      cmdsync;      //used to make the at command sync, binary sempore, only one at command could be excuted at one time
    OsalMutexT     cmdlock;      //make the command list atomic
}AtCmdItem;//the member cmd and cmdlen not used yet,will be used for the debug

typedef struct {
    const char *name;     ///< this function used for the oob item name
    FnAtOob    func;     ///<  the function that will deal the out of band data
    void       *args;     ///<  the function param for the function
    const char *index;    ///<  used to match the out of band data,only compared from the header
    size_t      len;   ///<  used for the index length
}AtOobItem;

typedef enum {
    EN_AT_DEBUG_NONE = 0,
    EN_AT_DEBUG_ASCII,
    EN_AT_DEBUG_HEX,
}EnAtRxtxDebugmode;        //FUNCTION USED TO CONTROL THE DEBUG MODE

typedef struct {
    AtCmdItem             cmd;      //the at command,only one command could be excuted
    AtOobItem             oob[CONFIG_AT_OOBTABLEN];        //storage the out of band dealer
    char                    rcvbuf[CONFIG_AT_RECVMAXLEN];     //used storage one frame,read from the at channel
    unsigned int            rxdebugmode:2;                 //receive debug mode
    unsigned int            txdebugmode:2;                 //send debug mode

    int                     streammode;
}AtCbT;
static AtCbT g_AtCb;   //this is the at controller here

__attribute__((weak))  int UartAtSend(const char *buf, size_t len,uint32_t timeout)
{
    printf("%s:###please implement this function by yourself####\n\r",__FUNCTION__);
    return -1;
}

__attribute__((weak))  int UartAtReceive(void *buf, size_t len, uint32_t timeout)
{
    printf("%s:###please implement this function by yourself####\n\r",__FUNCTION__);
    return -1;
}

static void PrintAscii(const char *index,const uint8_t *data, int len)
{
    int i = 0;

    printf("%s:%d bytes:", index, len);
    for ( i = 0; i < len; i++) {
        if (isprint((int)data[i])) {
            printf("%c", (char)data[i]);
        } else {
            printf("\\%02x ", (int)((int)data[i]));
        }
    }
    printf("\r\n");
}

static void PrintHex(const char *index, const uint8_t *data, int len)
{
    int i = 0;
    printf("%s:%d bytes:", index, len);
    for (i = 0; i < len; i++) {
        printf("%02x ", *((uint8_t *)(data) + i));
    }
    printf("\r\n");
}

static void PrintPayload(const char *index, const uint8_t *data, int len, EnAtRxtxDebugmode mode)
{
    if(mode == EN_AT_DEBUG_ASCII) {
        PrintAscii(index, data, len);
    } else if (mode == EN_AT_DEBUG_HEX) {
        PrintHex(index,data, len);
    } else {
    }
}


//this function used to send the data to the AT channel
static int __CmdSend(const void *buf, size_t buflen, uint32_t timeout)
{
    ssize_t ret = 0;

    ret = UartAtSend(buf, buflen, timeout);
    if(ret > 0) {
        PrintPayload("ATSND", buf, buflen, g_AtCb.txdebugmode);
        ret = 0;
    } else {
        ret = -1;
    }
    return ret;
}

//this function used to receive data from the AT channel
static int __RespRcv(void *buf, size_t buflen, uint32_t timeout)
{
    ssize_t ret = 0;

    ret = UartAtReceive(buf, buflen, timeout);

    if (ret > 0) {
        PrintPayload("ATRCV", buf, ret, g_AtCb.rxdebugmode);
    }

    return ret;
}

//create a command
static int __CmdCreate(const void *cmdbuf, size_t cmdlen, const char *index, void *respbuf, \
                             size_t respbuflen, uint32_t timeout)
{
    int  ret = -1;
    AtCmdItem *cmd;

    cmd = &g_AtCb.cmd;
    if (ChOsalSempPend(cmd->cmdsync, timeout)) {
        if (ChOsalMutexLock(cmd->cmdlock)) {
            cmd->cmd = cmdbuf;
            cmd->cmdlen = cmdlen;
            cmd->index = index;
            cmd->respbuf = respbuf;
            cmd->respbuflen = respbuflen;
            (void) ChOsalSempPend(cmd->respsync, 0); //used to clear the sync
            (void) ChOsalMutexUnlock(cmd->cmdlock);
        }
        ret = 0;
    }
    return ret;
}

//clear the at command here
static int __CmdClear(void)
{
     AtCmdItem *cmd;

     cmd = &g_AtCb.cmd;
     if (ChOsalMutexLock(cmd->cmdlock)) {
        cmd->cmd = NULL;
        cmd->cmdlen = 0;
        cmd->index = NULL;
        cmd->respbuf = NULL;
        cmd->respbuflen = 0;
        cmd->respdatalen = 0;
        (void) ChOsalMutexUnlock(cmd->cmdlock);
     }
     (void) ChOsalSempPost(cmd->cmdsync);
     return 0;
}

//check if the data received is the at command need
static int  __CmdMatch(const void *data,size_t len)
{
    int  ret = -1;
    int  cpylen;
    AtCmdItem *cmd = NULL;

    cmd = &g_AtCb.cmd;
    if (ChOsalMutexLock(cmd->cmdlock)) {
        if ((NULL != cmd->index) && (NULL != strstr((const char *)data, cmd->index))) {
            if (NULL != cmd->respbuf) {
                cpylen = len > cmd->respbuflen ? cmd->respbuflen : len;
                (void) memcpy((char *)cmd->respbuf, data, cpylen);
                cmd->respdatalen = cpylen;
            } else {
                cmd->respdatalen = len; //tell the command that how many data has been get
            }
            (void) ChOsalSempPost(cmd->respsync);
            ret = 0;
        }
        (void) ChOsalMutexUnlock(cmd->cmdlock);
    }
    return ret;
}

//check if any out of band method could deal the data
static int  __OobMatch(void *data, size_t len)
{
    int ret = -1;
    AtOobItem *oob;
    int i = 0;
    for (i = 0; i < CONFIG_AT_OOBTABLEN; i++) {
        oob = &g_AtCb.oob[i];
        if ((oob->func != NULL) && (oob->index != NULL) &&\
            (0 == memcmp(oob->index, data,oob->len))) {
            oob->func(oob->args, data, len);
            ret = 0;
            break;
        }
    }
    return ret;
}

/*******************************************************************************
function     :this is the  at receiver engine
parameters   :
instruction  :this task read the device continousely and blocked by the read function
              if pass by mode, then pass it to the pass function;else will match the 
              at command, if not then match the out of band
*******************************************************************************/
static int __RcvTaskEntry(void *args)
{
    int  rcvlen = 0;

    /* 此处需先判断串口句柄 */

    while (1) {
        if (1 == g_AtCb.streammode) { //in stream mode, we need to save previous frames in buffer
            if (rcvlen == 0) {
                (void)memset(g_AtCb.rcvbuf, 0, CONFIG_AT_RECVMAXLEN);
            }
            rcvlen += __RespRcv(g_AtCb.rcvbuf+ rcvlen, CONFIG_AT_RECVMAXLEN, CN_OSAL_TIMEOUT_FOREVER);
            if (rcvlen > 0) {
                if (0 != __OobMatch(g_AtCb.rcvbuf, rcvlen)) {
                    if (0 == __CmdMatch(g_AtCb.rcvbuf, rcvlen)) {
                        rcvlen = 0;
                    }
                } else {
                    rcvlen = 0;
                }
            }
        } else {
            (void) memset(g_AtCb.rcvbuf, 0, CONFIG_AT_RECVMAXLEN);
            rcvlen = __RespRcv(g_AtCb.rcvbuf, CONFIG_AT_RECVMAXLEN, CN_OSAL_TIMEOUT_FOREVER);
            if (rcvlen > 0) {
                if (0 != __OobMatch(g_AtCb.rcvbuf, rcvlen)) {
                    (void)__CmdMatch(g_AtCb.rcvbuf, rcvlen);
                }
            }
        }
    }
    return 0;
}

/*******************************************************************************
function     :you could use this function to to enable or disable at stream mode.
parameters   :mode:1 for stream mode, 0 for dgram mode.
instruction  :If stream mode is enabled, we can process data from multiple frames.
			  mode equals 0 by default.
*******************************************************************************/
int AtStreammodeSt(int mode)
{
    g_AtCb.streammode = mode;
    return 0;
}

int AtDebugclose(void)
{
    //for the debug
    g_AtCb.rxdebugmode = EN_AT_DEBUG_NONE;
    g_AtCb.txdebugmode = EN_AT_DEBUG_NONE;
    return 0;
}

/*******************************************************************************
function     :this is our at command here,you could send any command as you wish
parameters   :
instruction  :only one command could be dealt at one time, for we use the semphore
              here do the sync;if the respbuf is not NULL,then we will cpoy the 
              response data to the respbuf as much as the respbuflen permit
*******************************************************************************/
int AtCommand(const void *cmd, size_t cmdlen, const char *index, void *respbuf, \
                    size_t respbuflen, uint32_t timeout)
{
    int ret = -1;
    if (NULL == cmd) {
        return ret;
    }
    if (NULL != index) {
        ret = __CmdCreate(cmd, cmdlen, index, respbuf, respbuflen, timeout);
        if (0 == ret) {
            ret = __CmdSend(cmd, cmdlen, timeout);
            if (0 == ret) {
                if (ChOsalSempPend(g_AtCb.cmd.respsync, timeout)) {
                    ret = g_AtCb.cmd.respdatalen;
                } else {
                    ret = -1;
                }
            } else {
                ret = -1;
            }
            (void) __CmdClear();
        }
    } else {
        ret = __CmdSend(cmd, cmdlen, timeout);
    }
    return ret;
}

/*******************************************************************************
function     :you could use this function to register a method to deal the out of band data
parameters   :
instruction  :as you know, we only check the frame begin,using memcmp, so you must
              write the header of the frame as the index
*******************************************************************************/
int AtOobregister(const char *name, const void *index, size_t len, FnAtOob func, void *args)
{
    int ret = -1;
    AtOobItem *oob;
    int i = 0;

    if ((NULL == func) || (NULL == index)) {
        return ret;
    }

    for (i = 0; i < CONFIG_AT_OOBTABLEN; i++) {
        oob = &g_AtCb.oob[i];
        if ((oob->func == NULL) && (oob->index == NULL)) {
            oob->name = name;
            oob->index = index;
            oob->len = len;
            oob->func = func;
            oob->args = args;
            ret = 0;
            break;
        }
    }

    return ret;
}

/*******************************************************************************
function     :this is the  at module initialize function
parameters   :func_read:which will read a frame from the device
              func_write:which will be used to write a frame to the device
instruction  :if you want to use the at frame work, please call this function 
              please supply the function read and write.the read function must be
              a block function controlled by timeout
*******************************************************************************/
int AtInit()
{
    int ret = -1;

    (void) memset(&g_AtCb, 0, sizeof(g_AtCb));

    if (FALSE == ChOsalSempCreate(&g_AtCb.cmd.cmdsync, 1, 1)) {
        printf("%s:semp cmdsync create error\n\r", __FUNCTION__);
        goto EXIT_CMDSYNC;
    }
    if (FALSE == ChOsalSempCreate(&g_AtCb.cmd.respsync, 1, 0)) {
        printf("%s:semp respsync  create error\n\r", __FUNCTION__);
        goto EXIT_RESPSYNC;
    }
    if (FALSE == ChOsalMutexCreate(&g_AtCb.cmd.cmdlock)) {
        printf("%s:Mutex create error\n\r", __FUNCTION__);
        goto EXIT_CMDLOCK;
    }

    if (NULL == ChOsalTaskCreate("at_rcv", __RcvTaskEntry, NULL, 512, NULL, CONFIG_AT_TASKPRIOR)) {
        printf("%s:task create error\n\r", __FUNCTION__);
        goto EXIT_RCVTASK;
    }
    //for the debug
    g_AtCb.rxdebugmode = EN_AT_DEBUG_ASCII;
    g_AtCb.txdebugmode = EN_AT_DEBUG_ASCII;

    ret = 0;
    return ret;


EXIT_RCVTASK:
    (void) ChOsalMutexDel(&g_AtCb.cmd.cmdlock);
    g_AtCb.cmd.cmdlock = CN_MUTEX_INVALID;
EXIT_CMDLOCK:
    (void) ChOsalSempDel(&g_AtCb.cmd.respsync);
    g_AtCb.cmd.respsync = CN_SEMP_INVALID;
EXIT_RESPSYNC:
    (void) ChOsalSempDel(&g_AtCb.cmd.cmdsync);
    g_AtCb.cmd.cmdsync = CN_SEMP_INVALID;
EXIT_CMDSYNC:
    return ret;
}

