#!/bin/bash
if [ ! -n "$1" ] ;then
    make
    echo "you have not input a word, only make!"
else
    echo "the word you input is $1"
    if [[ "$1" == "cm" ]];then
        echo "make, clean..."
        make clean
        echo "make..."
        make
    fi
    if [[ "$1" == "d" ]];then
        make
        echo "dowmload program from /dev/tty.SLAB_USBtoUART......"
        stm32flash /dev/tty.SLAB_USBtoUART
        stm32flash -w build/stm32l422cbt6.hex -v -g 0 /dev/tty.SLAB_USBtoUART
    fi
    if [[ "$1" == "dl" ]];then
        make
        #echo "dowmload program from /dev/tty.SLAB_USBtoUART......"
        #stm32flash /dev/tty.SLAB_USBtoUART
        #stm32flash -w build/stm32l422cbt6.hex -v -g 0 /dev/tty.SLAB_USBtoUART
        echo "dowmload program from /dev/tty.usbserial......"
        stm32flash /dev/tty.usbserial
        stm32flash -w build/stm32l422cbt6.hex -v -g 0 /dev/tty.usbserial
    fi
    if [[ "$1" == "minior" ]];then
        make
        echo "dowmload program from /dev/tty.SLAB_USBtoUART......"
        stm32flash /dev/tty.SLAB_USBtoUART
        stm32flash -w build/stm32l422cbt6.hex -v -g 0 /dev/tty.SLAB_USBtoUART
        screen /dev/tty.SLAB_USBtoUART 115200
    fi
    if [[ "$1" == "clean" ]];then
        make clean
    fi
fi
