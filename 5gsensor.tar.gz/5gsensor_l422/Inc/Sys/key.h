//
// Created by zero on 20/8/31.
//

#ifndef STM32L422CBT6_KEY_H
#define STM32L422CBT6_KEY_H

#define	KEY_GPIOx   GPIOA
#define KEY_PIN		GPIO_PIN_12

#define KEY_READ_IO  HAL_GPIO_ReadPin(KEY_GPIOx, KEY_PIN)

enum {
    KEY_OPT_NONE = 0,
    KEY_OPT_SHORT,
    KEY_OPT_LONG,
};

int8_t KeyGpioInit(void);
uint8_t check_click_listener();

#endif //STM32L422CBT6_KEY_H
