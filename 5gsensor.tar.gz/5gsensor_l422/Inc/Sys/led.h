//
// Created by zero on 20/8/31.
//

#ifndef STM32L422CBT6_LED_H
#define STM32L422CBT6_LED_H

#define	LED_GPIOx  GPIOB
#define LED1_PIN		GPIO_PIN_0
#define LED2_PIN		GPIO_PIN_1

#define LED1_ON		HAL_GPIO_WritePin(LED_GPIOx, LED1_PIN, 0)
#define LED2_ON		HAL_GPIO_WritePin(LED_GPIOx, LED2_PIN, 0)

#define LED1_OFF		HAL_GPIO_WritePin(LED_GPIOx, LED1_PIN, 1)
#define LED2_OFF		HAL_GPIO_WritePin(LED_GPIOx, LED2_PIN, 1)

#define LED1_TOG	HAL_GPIO_TogglePin(LED_GPIOx, LED1_PIN)
#define LED2_TOG	HAL_GPIO_TogglePin(LED_GPIOx, LED2_PIN)

int8_t LedGpioInit(void);

#endif //STM32L422CBT6_LED_H
