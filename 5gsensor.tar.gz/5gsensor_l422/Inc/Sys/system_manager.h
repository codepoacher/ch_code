//
// Created by zero on 20/9/9.
//

#ifndef STM32L422CBT6_SYSTEM_MANAGER_H
#define STM32L422CBT6_SYSTEM_MANAGER_H

void MemoryHeapState(void);
int32_t SystemTestManagerInit();

#endif //STM32L422CBT6_SYSTEM_MANAGER_H
