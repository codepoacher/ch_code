/**
 *  DATE         AUTHOR            INSTRUCTION
 *  2020-08-03   liangsheng.jiang  The first version
 *
 */
#ifndef __REPORT_H
#define __REPORT_H

#ifdef __cplusplus
extern "C"
{
#endif
#include "sensor_manager.h"

#define DEV_TYPE_TH02 10401
#define DEV_TYPE_RE46C191 10402
#define DEV_TYPE_ZP07 10403

typedef struct {
    char *tempChar;
    char *humiChar;
} HumidityDataChar;

typedef struct {
    char *msg;
    int code;
    char *devId;
    int devType;
    union {
        HumidityDataChar humidityDataChar;
        SmokeData smokeData;
        AirData airData;
    };
}PropertiesReport;

int PropertiesReportToJson(char *msgbuf, PropertiesReport *propertiesReport);
int SensorsReportEntry(char *msgbuf, PropertiesReport *propertiesReport);

#ifdef __cplusplus
}
#endif

#endif /* __REPORT_H */