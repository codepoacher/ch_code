//
// Created by zero on 20/8/5.
//

#ifndef STM32L412CBT6_AT_DEVICE_H
#define STM32L412CBT6_AT_DEVICE_H
#include "usart.h"
#include <osal.h>
#include "ch_ring_buffer.h"

//#define PRODUCT_TEST 1

BOOL_T UartAtInit(void);
void UartAtDeinit(void);
int UartAtSend(const char *buf, size_t len,uint32_t timeout);
int UartAtReceive(void *buf, size_t len, uint32_t timeout);

void USER_UART_IRQHandler(UART_HandleTypeDef *huart);

#ifdef PRODUCT_TEST
int CommunicateTestInit(void);
#endif

#endif /* STM32L412CBT6_AT_DEVICE_H */

