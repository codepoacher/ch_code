//
// Created by zero on 20/8/6.
//

#ifndef STM32L412CBT6_COMMUNICATE_MANAGER_H
#define STM32L412CBT6_COMMUNICATE_MANAGER_H

//
// Created by zero on 20/8/6.
//

//
// Created by zero on 20/8/6.
//
#include <stdio.h>
#include "sensor_manager.h"

int32_t TransmitSensorData(SensorMail *sensorMail);
void TransmitSensorDatavoidIsr(SensorMail *sensorMail);
int32_t CommunicateManagerInit();

#endif //STM32L412CBT6_COMMUNICATE_MANAGER_H
