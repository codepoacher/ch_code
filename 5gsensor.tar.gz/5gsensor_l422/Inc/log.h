//
// Created by zero on 20/6/3.
//

#ifndef FREERTOS_ORI_C8_LOG_H
#define FREERTOS_ORI_C8_LOG_H

#ifdef __cplusplus
extern "C" {
#endif

#include "usart.h"

void st_printf(const char* buf, ...);
void st_printf_orienttering(UART_HandleTypeDef* huart,const char* buf, ...);

//char* st_conversion_float42(char *fData, float data);

#ifdef __cplusplus
}
#endif

#endif //FREERTOS_ORI_C8_LOG_H