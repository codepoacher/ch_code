//
// Created by zero on 20/6/15.
//

#ifndef LITEOS_ORI_C8_TH02_H
#define LITEOS_ORI_C8_TH02_H

#ifdef __cplusplus
 extern "C" {
#endif

#define TH02_ADDRESS 0x40

#define TH02_CONVERSION    0X03
#define TH02_CONVERSION_READ 0X01
#define TH02_RDY_READ 0x00
#define TH02_ID_READ 0x11

#define TH02_TEMP    0x11
#define TH02_HUMI    0X01

//#define TH02_LINEAR_A0    -4.7844
#define TH02_LINEAR_A0    4.7844
#define TH02_LINEAR_A1    0.4008
//#define TH02_LINEAR_A2    -0.00393
#define TH02_LINEAR_A2    0.00393

#define TH02_TEMPCOMP_Q0    0.1973
#define TH02_TEMPCOMP_Q1    0.000237

#define TH02_ADDR_WR  ((TH02_ADDRESS << 1) & 0xFE)
#define TH02_ADDR_RD  ((TH02_ADDRESS << 1) | 0x01)

char Th02Init(void);
uint32_t Th02Measure(uint8_t ucOrder);
float Th02MeasureCalculate(uint8_t ucOrder,uint16_t data);
float Th02HumiOrrection(float hData, float tData);

#ifdef __cplusplus
}
#endif

#endif //LITEOS_ORI_C8_TH02_H
