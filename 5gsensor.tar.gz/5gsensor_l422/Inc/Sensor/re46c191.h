#ifndef __RE46C191_H
#define __RE46C191_H

#ifdef __cplusplus
extern "C"
{
#endif

#define	RE46C191_GPIOx  GPIOA
#define RE46C191_PIN		 GPIO_PIN_11

#define RE46C191_READ_IO  HAL_GPIO_ReadPin(RE46C191_GPIOx, RE46C191_PIN)

typedef enum {
    SMOKE_NO_ALARM =0,
    SMOKE_ALARM,
} Re46c191Status;

typedef enum {
    SMOKE_ALARM_RESET =0,
    SMOKE_ALARM_SET,
} Re46c191Value;

uint8_t Re46c191Init();
int8_t Re46c191DataCollection(uint8_t *data);

#ifdef __cplusplus
}
#endif

#endif /* __RE46C191_H */