//
// Created by zero on 20/8/6.
//

#ifndef STM32L412CBT6_SENSOR_MANAGER_H
#define STM32L412CBT6_SENSOR_MANAGER_H

#include <stdio.h>

typedef enum {
    SENSOR_TYPE_HUMIDITY,
    SENSOR_TYPE_SMOKE,
    SENSOR_TYPE_AIR,
} SensorType;

typedef struct {
    uint32_t temp;
    uint32_t humi;
} HumidityData;

typedef struct {
    uint8_t status;
} SmokeData;

typedef struct {
    uint32_t qualityLevel;
} AirData;

typedef struct {
    SensorType type;
    union {
        HumidityData      humidityData;
        SmokeData         smokeData;
        AirData               airData;
    };
} SensorMail;

int32_t SensorManagerInit();

#endif //STM32L412CBT6_SENSOR_MANAGER_H
