#ifndef __ZP07_H
#define __ZP07_H

#ifdef __cplusplus
extern "C"
{
#endif

#define	ZP07_GPIOx  GPIOA
#define ZP07_PIN		GPIO_PIN_1

#define ZP07_READ_IO  HAL_GPIO_ReadPin(ZP07_GPIOx, ZP07_PIN)

#define ZP07_CTRL_PIN		GPIO_PIN_6
#define ZP07_CTRL_ENABLE	HAL_GPIO_WritePin(ZP07_GPIOx, ZP07_CTRL_PIN, 1)
#define ZP07_CTRL_DISABLE	HAL_GPIO_WritePin(ZP07_GPIOx, ZP07_CTRL_PIN, 0)

uint8_t Zp07Init();
int32_t Zp07DataCollection(void);

#ifdef __cplusplus
}
#endif

#endif /* __ZP07_H */